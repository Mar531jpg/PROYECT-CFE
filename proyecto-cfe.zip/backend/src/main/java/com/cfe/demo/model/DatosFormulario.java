package com.cfe.demo.model;

public class DatosFormulario {
    private String trabajador;
    private int horas;
    private String fecha;

    public String getTrabajador() { return trabajador; }
    public void setTrabajador(String trabajador) { this.trabajador = trabajador; }

    public int getHoras() { return horas; }
    public void setHoras(int horas) { this.horas = horas; }

    public String getFecha() { return fecha; }
    public void setFecha(String fecha) { this.fecha = fecha; }
}
